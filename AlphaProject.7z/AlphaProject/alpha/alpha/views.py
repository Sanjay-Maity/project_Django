# I have cteated this fiile ------ Sanjayir
from django.http import HttpResponse
from django.shortcuts import render
# from . import


def home(request):
    return HttpResponse('''<h2>Hello Sanjay</h2> <a href="about"> about sanjay</a>''')


def index(request):
    return render(request, "html/index.html")


def about(request):
    return HttpResponse("About Sanjay ")


def signup(request):
    return render(request, "html/signup.html")


def login(request):
    return render(request, "html/login.html")
